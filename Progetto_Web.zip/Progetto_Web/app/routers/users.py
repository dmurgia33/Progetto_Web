from fastapi import APIRouter, Request, Depends, HTTPException, Path
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.config import config
from app.data.db import SessionDep
from app.models.event import Event, EventRead, EventCreate
from sqlmodel import select, Session,delete
from typing import List, Annotated
from app.models.user import User, UserRead, UserCreate
from app.models.registration import Registration


router = APIRouter(prefix="/users", tags=["users"],)




@router.get("/", response_model=List[UserRead])
def get_users(session: SessionDep):
    users = session.exec(select(User)).all()
    return users




@router.post("/", response_model=UserRead)
def create_user(user: UserCreate, session: SessionDep):
    existing = session.get(User, user.username)
    if existing:
        raise HTTPException(status_code=400, detail="Username già esistente")
    new_user = User(**user.dict())
    session.add(new_user)
    session.commit()
    session.refresh(new_user)
    return new_user

@router.get("/{username}", response_model=UserRead)
def get_user_by_username(username: Annotated[str, Path()], session: SessionDep):
    user = session.get(User, username)
    if not user:
        raise HTTPException(status_code=404, detail="Utente non trovato")
    return user

@router.delete("/", status_code=200)
def delete_all_users(session: SessionDep):
    session.exec(delete(User))
    session.commit()
    return {"Tutti gli utenti sono stati eliminati"}

@router.delete("/{username}", status_code=200)
def delete_user_by_username(username: Annotated[str, Path()], session: SessionDep):
    user = session.get(User, username)
    if not user:
        raise HTTPException(status_code=404, detail="Utente non trovato")
    session.delete(user)
    session.commit()
    return {f"Utente '{username}' eliminato"}

