from fastapi import APIRouter, Request, Depends, HTTPException, Path
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.config import config
from app.data.db import SessionDep
from app.models.event import Event, EventRead, EventCreate
from sqlmodel import select, Session,delete
from typing import List, Annotated
from app.models.user import User
from app.models.registration import Registration


router = APIRouter(prefix="/users", tags=["users"],)


# Definisci prima tutti gli endpoint GET

@router.get("/", response_model=List[User])
def get_users(session: SessionDep):
    statement = select(User)
    users = session.exec(statement).all()
    return users